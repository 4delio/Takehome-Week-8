﻿namespace Takehome_08_Adelio_Surya_Putra_Pratama
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menu = new System.Windows.Forms.MenuStrip();
            this.ms_top = new System.Windows.Forms.ToolStripMenuItem();
            this.ms_tshirt = new System.Windows.Forms.ToolStripMenuItem();
            this.ms_shirt = new System.Windows.Forms.ToolStripMenuItem();
            this.ms_bot = new System.Windows.Forms.ToolStripMenuItem();
            this.ms_pants = new System.Windows.Forms.ToolStripMenuItem();
            this.ms_lpants = new System.Windows.Forms.ToolStripMenuItem();
            this.ms_acc = new System.Windows.Forms.ToolStripMenuItem();
            this.ms_shoes = new System.Windows.Forms.ToolStripMenuItem();
            this.ms_jewel = new System.Windows.Forms.ToolStripMenuItem();
            this.ms_other = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_harga = new System.Windows.Forms.DataGridView();
            this.lbl_subtotal = new System.Windows.Forms.Label();
            this.lbl_total = new System.Windows.Forms.Label();
            this.tb_st = new System.Windows.Forms.TextBox();
            this.tb_t = new System.Windows.Forms.TextBox();
            this.panel_tshirt = new System.Windows.Forms.Panel();
            this.add_t_vneck = new System.Windows.Forms.Button();
            this.add_t_alrism = new System.Windows.Forms.Button();
            this.add_t_kerahbulat = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_shirt = new System.Windows.Forms.Panel();
            this.add_s_halfblue = new System.Windows.Forms.Button();
            this.add_s_colourblock = new System.Windows.Forms.Button();
            this.add_s_cotton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel_pants = new System.Windows.Forms.Panel();
            this.add_p_bisnis = new System.Windows.Forms.Button();
            this.add_p_jog = new System.Windows.Forms.Button();
            this.add_p_cargo = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panel_shorts = new System.Windows.Forms.Panel();
            this.add_sh_sports = new System.Windows.Forms.Button();
            this.add_sh_casual = new System.Windows.Forms.Button();
            this.add_sh_cargo = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel_shoes = new System.Windows.Forms.Panel();
            this.add_shoes_superstar = new System.Windows.Forms.Button();
            this.add_shoes_nike = new System.Windows.Forms.Button();
            this.add_shoes_adidas = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.add_a_sunglas = new System.Windows.Forms.Button();
            this.add_a_rolex = new System.Windows.Forms.Button();
            this.add_a_mask = new System.Windows.Forms.Button();
            this.panel_acc = new System.Windows.Forms.Panel();
            this.panel_other = new System.Windows.Forms.Panel();
            this.btn_upload = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.tb_other_price = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.tb_other_name = new System.Windows.Forms.TextBox();
            this.add_other = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.btn_delete = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.pb_upload = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_harga)).BeginInit();
            this.panel_tshirt.SuspendLayout();
            this.panel_shirt.SuspendLayout();
            this.panel_pants.SuspendLayout();
            this.panel_shorts.SuspendLayout();
            this.panel_shoes.SuspendLayout();
            this.panel_acc.SuspendLayout();
            this.panel_other.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_upload)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menu
            // 
            this.menu.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.menu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ms_top,
            this.ms_bot,
            this.ms_acc,
            this.ms_other});
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menu.Size = new System.Drawing.Size(955, 28);
            this.menu.TabIndex = 1;
            this.menu.Text = "menuStrip1";
            // 
            // ms_top
            // 
            this.ms_top.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ms_tshirt,
            this.ms_shirt});
            this.ms_top.Name = "ms_top";
            this.ms_top.Size = new System.Drawing.Size(86, 24);
            this.ms_top.Text = "Top Wear";
            // 
            // ms_tshirt
            // 
            this.ms_tshirt.Name = "ms_tshirt";
            this.ms_tshirt.Size = new System.Drawing.Size(136, 26);
            this.ms_tshirt.Text = "T-Shirt";
            this.ms_tshirt.Click += new System.EventHandler(this.ms_tshirt_Click);
            // 
            // ms_shirt
            // 
            this.ms_shirt.Name = "ms_shirt";
            this.ms_shirt.Size = new System.Drawing.Size(136, 26);
            this.ms_shirt.Text = "Shirt";
            this.ms_shirt.Click += new System.EventHandler(this.ms_shirt_Click);
            // 
            // ms_bot
            // 
            this.ms_bot.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ms_pants,
            this.ms_lpants});
            this.ms_bot.Name = "ms_bot";
            this.ms_bot.Size = new System.Drawing.Size(111, 24);
            this.ms_bot.Text = "Bottom Wear";
            // 
            // ms_pants
            // 
            this.ms_pants.Name = "ms_pants";
            this.ms_pants.Size = new System.Drawing.Size(163, 26);
            this.ms_pants.Text = "Pants";
            this.ms_pants.Click += new System.EventHandler(this.ms_pants_Click);
            // 
            // ms_lpants
            // 
            this.ms_lpants.Name = "ms_lpants";
            this.ms_lpants.Size = new System.Drawing.Size(163, 26);
            this.ms_lpants.Text = "Long Pants";
            this.ms_lpants.Click += new System.EventHandler(this.ms_lpants_Click);
            // 
            // ms_acc
            // 
            this.ms_acc.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ms_shoes,
            this.ms_jewel});
            this.ms_acc.Name = "ms_acc";
            this.ms_acc.Size = new System.Drawing.Size(99, 24);
            this.ms_acc.Text = "Accessories";
            // 
            // ms_shoes
            // 
            this.ms_shoes.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ms_shoes.Name = "ms_shoes";
            this.ms_shoes.Size = new System.Drawing.Size(163, 26);
            this.ms_shoes.Text = "Shoes";
            this.ms_shoes.Click += new System.EventHandler(this.ms_shoes_Click);
            // 
            // ms_jewel
            // 
            this.ms_jewel.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ms_jewel.Name = "ms_jewel";
            this.ms_jewel.Size = new System.Drawing.Size(163, 26);
            this.ms_jewel.Text = "Jewelleries";
            this.ms_jewel.Click += new System.EventHandler(this.ms_jewel_Click);
            // 
            // ms_other
            // 
            this.ms_other.Name = "ms_other";
            this.ms_other.Size = new System.Drawing.Size(60, 24);
            this.ms_other.Text = "Other";
            this.ms_other.Click += new System.EventHandler(this.ms_other_Click);
            // 
            // dgv_harga
            // 
            this.dgv_harga.AllowUserToAddRows = false;
            this.dgv_harga.AllowUserToResizeColumns = false;
            this.dgv_harga.AllowUserToResizeRows = false;
            this.dgv_harga.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_harga.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_harga.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_harga.Location = new System.Drawing.Point(516, 32);
            this.dgv_harga.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgv_harga.Name = "dgv_harga";
            this.dgv_harga.RowHeadersWidth = 51;
            this.dgv_harga.RowTemplate.Height = 24;
            this.dgv_harga.Size = new System.Drawing.Size(427, 369);
            this.dgv_harga.TabIndex = 3;
            // 
            // lbl_subtotal
            // 
            this.lbl_subtotal.AutoSize = true;
            this.lbl_subtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_subtotal.Location = new System.Drawing.Point(312, 441);
            this.lbl_subtotal.Name = "lbl_subtotal";
            this.lbl_subtotal.Size = new System.Drawing.Size(211, 42);
            this.lbl_subtotal.TabIndex = 4;
            this.lbl_subtotal.Text = "Sub-Total :";
            // 
            // lbl_total
            // 
            this.lbl_total.AutoSize = true;
            this.lbl_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_total.Location = new System.Drawing.Point(395, 512);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(128, 42);
            this.lbl_total.TabIndex = 5;
            this.lbl_total.Text = "Total :";
            // 
            // tb_st
            // 
            this.tb_st.Enabled = false;
            this.tb_st.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_st.Location = new System.Drawing.Point(516, 441);
            this.tb_st.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_st.Name = "tb_st";
            this.tb_st.Size = new System.Drawing.Size(425, 49);
            this.tb_st.TabIndex = 6;
            this.tb_st.Text = "Rp. 0";
            // 
            // tb_t
            // 
            this.tb_t.Enabled = false;
            this.tb_t.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_t.Location = new System.Drawing.Point(516, 510);
            this.tb_t.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_t.Name = "tb_t";
            this.tb_t.Size = new System.Drawing.Size(425, 49);
            this.tb_t.TabIndex = 7;
            this.tb_t.Text = "Rp. 0";
            // 
            // panel_tshirt
            // 
            this.panel_tshirt.Controls.Add(this.add_t_vneck);
            this.panel_tshirt.Controls.Add(this.add_t_alrism);
            this.panel_tshirt.Controls.Add(this.add_t_kerahbulat);
            this.panel_tshirt.Controls.Add(this.label6);
            this.panel_tshirt.Controls.Add(this.label5);
            this.panel_tshirt.Controls.Add(this.label4);
            this.panel_tshirt.Controls.Add(this.label3);
            this.panel_tshirt.Controls.Add(this.pictureBox3);
            this.panel_tshirt.Controls.Add(this.label2);
            this.panel_tshirt.Controls.Add(this.pictureBox2);
            this.panel_tshirt.Controls.Add(this.label1);
            this.panel_tshirt.Controls.Add(this.pictureBox1);
            this.panel_tshirt.Location = new System.Drawing.Point(13, 32);
            this.panel_tshirt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_tshirt.Name = "panel_tshirt";
            this.panel_tshirt.Size = new System.Drawing.Size(497, 260);
            this.panel_tshirt.TabIndex = 8;
            this.panel_tshirt.Visible = false;
            // 
            // add_t_vneck
            // 
            this.add_t_vneck.Location = new System.Drawing.Point(357, 229);
            this.add_t_vneck.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_t_vneck.Name = "add_t_vneck";
            this.add_t_vneck.Size = new System.Drawing.Size(133, 23);
            this.add_t_vneck.TabIndex = 14;
            this.add_t_vneck.Text = "Add to Cart";
            this.add_t_vneck.UseVisualStyleBackColor = true;
            this.add_t_vneck.Click += new System.EventHandler(this.add_t_vneck_Click);
            // 
            // add_t_alrism
            // 
            this.add_t_alrism.Location = new System.Drawing.Point(181, 229);
            this.add_t_alrism.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_t_alrism.Name = "add_t_alrism";
            this.add_t_alrism.Size = new System.Drawing.Size(133, 23);
            this.add_t_alrism.TabIndex = 13;
            this.add_t_alrism.Text = "Add to Cart";
            this.add_t_alrism.UseVisualStyleBackColor = true;
            this.add_t_alrism.Click += new System.EventHandler(this.add_t_alrism_Click);
            // 
            // add_t_kerahbulat
            // 
            this.add_t_kerahbulat.Location = new System.Drawing.Point(5, 229);
            this.add_t_kerahbulat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_t_kerahbulat.Name = "add_t_kerahbulat";
            this.add_t_kerahbulat.Size = new System.Drawing.Size(133, 23);
            this.add_t_kerahbulat.TabIndex = 12;
            this.add_t_kerahbulat.Text = "Add to Cart";
            this.add_t_kerahbulat.UseVisualStyleBackColor = true;
            this.add_t_kerahbulat.Click += new System.EventHandler(this.add_t_kerahbulat_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(355, 204);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 15);
            this.label6.TabIndex = 11;
            this.label6.Text = "Rp.170.000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(179, 204);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "Rp.150.000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 204);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 15);
            this.label4.TabIndex = 9;
            this.label4.Text = "Rp.120.000";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(357, 183);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "T-Shirt VNeck";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(181, 183);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "Alrism T-Shirt";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 183);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "T-Shirt Kerah Bulat";
            // 
            // panel_shirt
            // 
            this.panel_shirt.Controls.Add(this.add_s_halfblue);
            this.panel_shirt.Controls.Add(this.add_s_colourblock);
            this.panel_shirt.Controls.Add(this.add_s_cotton);
            this.panel_shirt.Controls.Add(this.label7);
            this.panel_shirt.Controls.Add(this.label8);
            this.panel_shirt.Controls.Add(this.label9);
            this.panel_shirt.Controls.Add(this.label10);
            this.panel_shirt.Controls.Add(this.pictureBox4);
            this.panel_shirt.Controls.Add(this.label11);
            this.panel_shirt.Controls.Add(this.pictureBox5);
            this.panel_shirt.Controls.Add(this.label12);
            this.panel_shirt.Controls.Add(this.pictureBox6);
            this.panel_shirt.Location = new System.Drawing.Point(13, 31);
            this.panel_shirt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_shirt.Name = "panel_shirt";
            this.panel_shirt.Size = new System.Drawing.Size(497, 260);
            this.panel_shirt.TabIndex = 15;
            this.panel_shirt.Visible = false;
            // 
            // add_s_halfblue
            // 
            this.add_s_halfblue.Location = new System.Drawing.Point(357, 229);
            this.add_s_halfblue.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_s_halfblue.Name = "add_s_halfblue";
            this.add_s_halfblue.Size = new System.Drawing.Size(133, 23);
            this.add_s_halfblue.TabIndex = 14;
            this.add_s_halfblue.Text = "Add to Cart";
            this.add_s_halfblue.UseVisualStyleBackColor = true;
            this.add_s_halfblue.Click += new System.EventHandler(this.add_s_halfblue_Click);
            // 
            // add_s_colourblock
            // 
            this.add_s_colourblock.Location = new System.Drawing.Point(181, 229);
            this.add_s_colourblock.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_s_colourblock.Name = "add_s_colourblock";
            this.add_s_colourblock.Size = new System.Drawing.Size(133, 23);
            this.add_s_colourblock.TabIndex = 13;
            this.add_s_colourblock.Text = "Add to Cart";
            this.add_s_colourblock.UseVisualStyleBackColor = true;
            this.add_s_colourblock.Click += new System.EventHandler(this.add_s_colourblock_Click);
            // 
            // add_s_cotton
            // 
            this.add_s_cotton.Location = new System.Drawing.Point(5, 229);
            this.add_s_cotton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_s_cotton.Name = "add_s_cotton";
            this.add_s_cotton.Size = new System.Drawing.Size(133, 23);
            this.add_s_cotton.TabIndex = 12;
            this.add_s_cotton.Text = "Add to Cart";
            this.add_s_cotton.UseVisualStyleBackColor = true;
            this.add_s_cotton.Click += new System.EventHandler(this.add_s_cotton_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(355, 204);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 15);
            this.label7.TabIndex = 11;
            this.label7.Text = "Rp.169.000";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(179, 204);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 15);
            this.label8.TabIndex = 10;
            this.label8.Text = "Rp.175.000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 204);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 15);
            this.label9.TabIndex = 9;
            this.label9.Text = "Rp.159.000";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(357, 183);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 15);
            this.label10.TabIndex = 8;
            this.label10.Text = "Halfblue Shirt";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(181, 183);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(117, 15);
            this.label11.TabIndex = 6;
            this.label11.Text = "Colourblock Shirt";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 183);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 15);
            this.label12.TabIndex = 4;
            this.label12.Text = "Cotton Shirt";
            // 
            // panel_pants
            // 
            this.panel_pants.Controls.Add(this.add_p_bisnis);
            this.panel_pants.Controls.Add(this.add_p_jog);
            this.panel_pants.Controls.Add(this.add_p_cargo);
            this.panel_pants.Controls.Add(this.label13);
            this.panel_pants.Controls.Add(this.label14);
            this.panel_pants.Controls.Add(this.label15);
            this.panel_pants.Controls.Add(this.label16);
            this.panel_pants.Controls.Add(this.pictureBox7);
            this.panel_pants.Controls.Add(this.label17);
            this.panel_pants.Controls.Add(this.pictureBox8);
            this.panel_pants.Controls.Add(this.label18);
            this.panel_pants.Controls.Add(this.pictureBox9);
            this.panel_pants.Location = new System.Drawing.Point(9, 31);
            this.panel_pants.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_pants.Name = "panel_pants";
            this.panel_pants.Size = new System.Drawing.Size(497, 260);
            this.panel_pants.TabIndex = 16;
            this.panel_pants.Visible = false;
            // 
            // add_p_bisnis
            // 
            this.add_p_bisnis.Location = new System.Drawing.Point(357, 229);
            this.add_p_bisnis.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_p_bisnis.Name = "add_p_bisnis";
            this.add_p_bisnis.Size = new System.Drawing.Size(133, 23);
            this.add_p_bisnis.TabIndex = 14;
            this.add_p_bisnis.Text = "Add to Cart";
            this.add_p_bisnis.UseVisualStyleBackColor = true;
            this.add_p_bisnis.Click += new System.EventHandler(this.add_p_bisnis_Click);
            // 
            // add_p_jog
            // 
            this.add_p_jog.Location = new System.Drawing.Point(181, 229);
            this.add_p_jog.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_p_jog.Name = "add_p_jog";
            this.add_p_jog.Size = new System.Drawing.Size(133, 23);
            this.add_p_jog.TabIndex = 13;
            this.add_p_jog.Text = "Add to Cart";
            this.add_p_jog.UseVisualStyleBackColor = true;
            this.add_p_jog.Click += new System.EventHandler(this.add_p_jog_Click);
            // 
            // add_p_cargo
            // 
            this.add_p_cargo.Location = new System.Drawing.Point(5, 229);
            this.add_p_cargo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_p_cargo.Name = "add_p_cargo";
            this.add_p_cargo.Size = new System.Drawing.Size(133, 23);
            this.add_p_cargo.TabIndex = 12;
            this.add_p_cargo.Text = "Add to Cart";
            this.add_p_cargo.UseVisualStyleBackColor = true;
            this.add_p_cargo.Click += new System.EventHandler(this.add_p_cargo_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(355, 204);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 15);
            this.label13.TabIndex = 11;
            this.label13.Text = "Rp.139.000";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(179, 204);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 15);
            this.label14.TabIndex = 10;
            this.label14.Text = "Rp.115.000";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(3, 204);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 15);
            this.label15.TabIndex = 9;
            this.label15.Text = "Rp.159.000";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(357, 183);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(105, 15);
            this.label16.TabIndex = 8;
            this.label16.Text = "Business Pants";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(181, 183);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(98, 15);
            this.label17.TabIndex = 6;
            this.label17.Text = "Jogging Pants";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(3, 183);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(85, 15);
            this.label18.TabIndex = 4;
            this.label18.Text = "Cargo Pants";
            // 
            // panel_shorts
            // 
            this.panel_shorts.Controls.Add(this.add_sh_sports);
            this.panel_shorts.Controls.Add(this.add_sh_casual);
            this.panel_shorts.Controls.Add(this.add_sh_cargo);
            this.panel_shorts.Controls.Add(this.label19);
            this.panel_shorts.Controls.Add(this.label20);
            this.panel_shorts.Controls.Add(this.label21);
            this.panel_shorts.Controls.Add(this.label22);
            this.panel_shorts.Controls.Add(this.pictureBox10);
            this.panel_shorts.Controls.Add(this.label23);
            this.panel_shorts.Controls.Add(this.pictureBox11);
            this.panel_shorts.Controls.Add(this.label24);
            this.panel_shorts.Controls.Add(this.pictureBox12);
            this.panel_shorts.Location = new System.Drawing.Point(9, 41);
            this.panel_shorts.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_shorts.Name = "panel_shorts";
            this.panel_shorts.Size = new System.Drawing.Size(497, 260);
            this.panel_shorts.TabIndex = 17;
            this.panel_shorts.Visible = false;
            // 
            // add_sh_sports
            // 
            this.add_sh_sports.Location = new System.Drawing.Point(357, 229);
            this.add_sh_sports.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_sh_sports.Name = "add_sh_sports";
            this.add_sh_sports.Size = new System.Drawing.Size(133, 23);
            this.add_sh_sports.TabIndex = 14;
            this.add_sh_sports.Text = "Add to Cart";
            this.add_sh_sports.UseVisualStyleBackColor = true;
            this.add_sh_sports.Click += new System.EventHandler(this.add_sh_sports_Click);
            // 
            // add_sh_casual
            // 
            this.add_sh_casual.Location = new System.Drawing.Point(181, 229);
            this.add_sh_casual.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_sh_casual.Name = "add_sh_casual";
            this.add_sh_casual.Size = new System.Drawing.Size(133, 23);
            this.add_sh_casual.TabIndex = 13;
            this.add_sh_casual.Text = "Add to Cart";
            this.add_sh_casual.UseVisualStyleBackColor = true;
            this.add_sh_casual.Click += new System.EventHandler(this.add_sh_casual_Click);
            // 
            // add_sh_cargo
            // 
            this.add_sh_cargo.Location = new System.Drawing.Point(5, 229);
            this.add_sh_cargo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_sh_cargo.Name = "add_sh_cargo";
            this.add_sh_cargo.Size = new System.Drawing.Size(133, 23);
            this.add_sh_cargo.TabIndex = 12;
            this.add_sh_cargo.Text = "Add to Cart";
            this.add_sh_cargo.UseVisualStyleBackColor = true;
            this.add_sh_cargo.Click += new System.EventHandler(this.add_sh_cargo_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(355, 204);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 15);
            this.label19.TabIndex = 11;
            this.label19.Text = "Rp.119.000";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(179, 204);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(71, 15);
            this.label20.TabIndex = 10;
            this.label20.Text = "Rp.110.000";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(3, 204);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(71, 15);
            this.label21.TabIndex = 9;
            this.label21.Text = "Rp.109.000";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(357, 183);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(93, 15);
            this.label22.TabIndex = 8;
            this.label22.Text = "Sports Shorts";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(181, 183);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(154, 15);
            this.label23.TabIndex = 6;
            this.label23.Text = "Summer Casual Shorts";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(3, 183);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(88, 15);
            this.label24.TabIndex = 4;
            this.label24.Text = "Cargo shorts";
            // 
            // panel_shoes
            // 
            this.panel_shoes.Controls.Add(this.add_shoes_superstar);
            this.panel_shoes.Controls.Add(this.add_shoes_nike);
            this.panel_shoes.Controls.Add(this.add_shoes_adidas);
            this.panel_shoes.Controls.Add(this.label25);
            this.panel_shoes.Controls.Add(this.label26);
            this.panel_shoes.Controls.Add(this.label27);
            this.panel_shoes.Controls.Add(this.label28);
            this.panel_shoes.Controls.Add(this.pictureBox13);
            this.panel_shoes.Controls.Add(this.label29);
            this.panel_shoes.Controls.Add(this.pictureBox14);
            this.panel_shoes.Controls.Add(this.label30);
            this.panel_shoes.Controls.Add(this.pictureBox15);
            this.panel_shoes.Location = new System.Drawing.Point(6, 31);
            this.panel_shoes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_shoes.Name = "panel_shoes";
            this.panel_shoes.Size = new System.Drawing.Size(497, 260);
            this.panel_shoes.TabIndex = 18;
            this.panel_shoes.Visible = false;
            // 
            // add_shoes_superstar
            // 
            this.add_shoes_superstar.Location = new System.Drawing.Point(357, 229);
            this.add_shoes_superstar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_shoes_superstar.Name = "add_shoes_superstar";
            this.add_shoes_superstar.Size = new System.Drawing.Size(133, 23);
            this.add_shoes_superstar.TabIndex = 14;
            this.add_shoes_superstar.Text = "Add to Cart";
            this.add_shoes_superstar.UseVisualStyleBackColor = true;
            this.add_shoes_superstar.Click += new System.EventHandler(this.add_shoes_superstar_Click);
            // 
            // add_shoes_nike
            // 
            this.add_shoes_nike.Location = new System.Drawing.Point(181, 229);
            this.add_shoes_nike.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_shoes_nike.Name = "add_shoes_nike";
            this.add_shoes_nike.Size = new System.Drawing.Size(133, 23);
            this.add_shoes_nike.TabIndex = 13;
            this.add_shoes_nike.Text = "Add to Cart";
            this.add_shoes_nike.UseVisualStyleBackColor = true;
            this.add_shoes_nike.Click += new System.EventHandler(this.add_shoes_nike_Click);
            // 
            // add_shoes_adidas
            // 
            this.add_shoes_adidas.Location = new System.Drawing.Point(5, 229);
            this.add_shoes_adidas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_shoes_adidas.Name = "add_shoes_adidas";
            this.add_shoes_adidas.Size = new System.Drawing.Size(133, 23);
            this.add_shoes_adidas.TabIndex = 12;
            this.add_shoes_adidas.Text = "Add to Cart";
            this.add_shoes_adidas.UseVisualStyleBackColor = true;
            this.add_shoes_adidas.Click += new System.EventHandler(this.add_shoes_adidas_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(355, 204);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(71, 15);
            this.label25.TabIndex = 11;
            this.label25.Text = "Rp.239.000";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(179, 204);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(71, 15);
            this.label26.TabIndex = 10;
            this.label26.Text = "Rp.550.000";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(3, 204);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(71, 15);
            this.label27.TabIndex = 9;
            this.label27.Text = "Rp.379.000";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(357, 183);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(133, 15);
            this.label28.TabIndex = 8;
            this.label28.Text = "Superstar Sneakers";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(181, 183);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(84, 15);
            this.label29.TabIndex = 6;
            this.label29.Text = "Nike AirMax";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(3, 183);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(152, 15);
            this.label30.TabIndex = 4;
            this.label30.Text = "Adidas Running Shoes";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(3, 183);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(81, 15);
            this.label36.TabIndex = 4;
            this.label36.Text = "Sunglasses";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(181, 183);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(87, 15);
            this.label35.TabIndex = 6;
            this.label35.Text = "Rolex Watch";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(357, 183);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(100, 15);
            this.label34.TabIndex = 8;
            this.label34.Text = "Ring Necklace";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(3, 204);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(71, 15);
            this.label33.TabIndex = 9;
            this.label33.Text = "Rp.100.000";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(179, 204);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(71, 15);
            this.label32.TabIndex = 10;
            this.label32.Text = "Rp.500.000";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(355, 204);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(71, 15);
            this.label31.TabIndex = 11;
            this.label31.Text = "Rp.459.000";
            // 
            // add_a_sunglas
            // 
            this.add_a_sunglas.Location = new System.Drawing.Point(5, 229);
            this.add_a_sunglas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_a_sunglas.Name = "add_a_sunglas";
            this.add_a_sunglas.Size = new System.Drawing.Size(133, 23);
            this.add_a_sunglas.TabIndex = 12;
            this.add_a_sunglas.Text = "Add to Cart";
            this.add_a_sunglas.UseVisualStyleBackColor = true;
            this.add_a_sunglas.Click += new System.EventHandler(this.add_a_sunglas_Click);
            // 
            // add_a_rolex
            // 
            this.add_a_rolex.Location = new System.Drawing.Point(181, 229);
            this.add_a_rolex.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_a_rolex.Name = "add_a_rolex";
            this.add_a_rolex.Size = new System.Drawing.Size(133, 23);
            this.add_a_rolex.TabIndex = 13;
            this.add_a_rolex.Text = "Add to Cart";
            this.add_a_rolex.UseVisualStyleBackColor = true;
            this.add_a_rolex.Click += new System.EventHandler(this.add_a_rolex_Click);
            // 
            // add_a_mask
            // 
            this.add_a_mask.Location = new System.Drawing.Point(357, 229);
            this.add_a_mask.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_a_mask.Name = "add_a_mask";
            this.add_a_mask.Size = new System.Drawing.Size(133, 23);
            this.add_a_mask.TabIndex = 14;
            this.add_a_mask.Text = "Add to Cart";
            this.add_a_mask.UseVisualStyleBackColor = true;
            this.add_a_mask.Click += new System.EventHandler(this.add_a_necklace_Click_1);
            // 
            // panel_acc
            // 
            this.panel_acc.Controls.Add(this.add_a_mask);
            this.panel_acc.Controls.Add(this.add_a_rolex);
            this.panel_acc.Controls.Add(this.add_a_sunglas);
            this.panel_acc.Controls.Add(this.label31);
            this.panel_acc.Controls.Add(this.label32);
            this.panel_acc.Controls.Add(this.label33);
            this.panel_acc.Controls.Add(this.label34);
            this.panel_acc.Controls.Add(this.pictureBox16);
            this.panel_acc.Controls.Add(this.label35);
            this.panel_acc.Controls.Add(this.pictureBox17);
            this.panel_acc.Controls.Add(this.label36);
            this.panel_acc.Controls.Add(this.pictureBox18);
            this.panel_acc.Location = new System.Drawing.Point(9, 29);
            this.panel_acc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_acc.Name = "panel_acc";
            this.panel_acc.Size = new System.Drawing.Size(497, 260);
            this.panel_acc.TabIndex = 19;
            this.panel_acc.Visible = false;
            // 
            // panel_other
            // 
            this.panel_other.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel_other.Controls.Add(this.btn_upload);
            this.panel_other.Controls.Add(this.label39);
            this.panel_other.Controls.Add(this.tb_other_price);
            this.panel_other.Controls.Add(this.label38);
            this.panel_other.Controls.Add(this.tb_other_name);
            this.panel_other.Controls.Add(this.add_other);
            this.panel_other.Controls.Add(this.label37);
            this.panel_other.Controls.Add(this.label40);
            this.panel_other.Controls.Add(this.pb_upload);
            this.panel_other.Location = new System.Drawing.Point(0, 29);
            this.panel_other.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_other.Name = "panel_other";
            this.panel_other.Size = new System.Drawing.Size(503, 407);
            this.panel_other.TabIndex = 20;
            this.panel_other.Visible = false;
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(175, 25);
            this.btn_upload.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(133, 26);
            this.btn_upload.TabIndex = 19;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(268, 192);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(72, 15);
            this.label39.TabIndex = 18;
            this.label39.Text = "Item Price";
            // 
            // tb_other_price
            // 
            this.tb_other_price.Enabled = false;
            this.tb_other_price.Location = new System.Drawing.Point(271, 222);
            this.tb_other_price.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_other_price.Name = "tb_other_price";
            this.tb_other_price.Size = new System.Drawing.Size(204, 22);
            this.tb_other_price.TabIndex = 17;
            this.tb_other_price.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_other_price_KeyPress);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(268, 110);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(77, 15);
            this.label38.TabIndex = 16;
            this.label38.Text = "Item Name";
            // 
            // tb_other_name
            // 
            this.tb_other_name.Enabled = false;
            this.tb_other_name.Location = new System.Drawing.Point(271, 139);
            this.tb_other_name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_other_name.Name = "tb_other_name";
            this.tb_other_name.Size = new System.Drawing.Size(204, 22);
            this.tb_other_name.TabIndex = 15;
            // 
            // add_other
            // 
            this.add_other.Enabled = false;
            this.add_other.Location = new System.Drawing.Point(67, 374);
            this.add_other.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_other.Name = "add_other";
            this.add_other.Size = new System.Drawing.Size(133, 30);
            this.add_other.TabIndex = 14;
            this.add_other.Text = "Add to Cart";
            this.add_other.UseVisualStyleBackColor = true;
            this.add_other.Click += new System.EventHandler(this.add_other_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(355, 204);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(0, 15);
            this.label37.TabIndex = 11;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(64, 25);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(97, 15);
            this.label40.TabIndex = 8;
            this.label40.Text = "Upload Image";
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(518, 405);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(425, 31);
            this.btn_delete.TabIndex = 21;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Transparent;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.Red;
            this.label41.Location = new System.Drawing.Point(284, 513);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(118, 42);
            this.label41.TabIndex = 22;
            this.label41.Text = "Tax +";
            // 
            // pb_upload
            // 
            this.pb_upload.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_upload.Location = new System.Drawing.Point(56, 57);
            this.pb_upload.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_upload.Name = "pb_upload";
            this.pb_upload.Size = new System.Drawing.Size(191, 290);
            this.pb_upload.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_upload.TabIndex = 5;
            this.pb_upload.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.necklace;
            this.pictureBox16.Location = new System.Drawing.Point(357, 2);
            this.pictureBox16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(136, 167);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox16.TabIndex = 7;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.rolex;
            this.pictureBox17.Location = new System.Drawing.Point(181, 2);
            this.pictureBox17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(136, 167);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox17.TabIndex = 5;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.sunglasses;
            this.pictureBox18.Location = new System.Drawing.Point(3, 2);
            this.pictureBox18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(136, 167);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox18.TabIndex = 0;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.sneakers;
            this.pictureBox13.Location = new System.Drawing.Point(357, 2);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(136, 167);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 7;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.airmax;
            this.pictureBox14.Location = new System.Drawing.Point(181, 2);
            this.pictureBox14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(136, 167);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox14.TabIndex = 5;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.adidas;
            this.pictureBox15.Location = new System.Drawing.Point(3, 2);
            this.pictureBox15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(136, 167);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox15.TabIndex = 0;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.sports;
            this.pictureBox10.Location = new System.Drawing.Point(357, 2);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(136, 167);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 7;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.summer;
            this.pictureBox11.Location = new System.Drawing.Point(181, 2);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(136, 167);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 5;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.cargo__2_;
            this.pictureBox12.Location = new System.Drawing.Point(3, 2);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(136, 167);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 0;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.bisnis;
            this.pictureBox7.Location = new System.Drawing.Point(357, 2);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(136, 167);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 7;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.joging_pants;
            this.pictureBox8.Location = new System.Drawing.Point(181, 2);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(136, 167);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 5;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.Loose_Fit_Men_s_Cargo_Pants_With_Flap_Pockets_And_Drawstring_Waist;
            this.pictureBox9.Location = new System.Drawing.Point(3, 2);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(136, 167);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.wedding_clothes_for_man_Best_Design_shirt;
            this.pictureBox4.Location = new System.Drawing.Point(357, 2);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(136, 167);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.Men_Colourblock_Button_Front_Shirt;
            this.pictureBox5.Location = new System.Drawing.Point(181, 2);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(136, 167);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.cotton_shirt;
            this.pictureBox6.Location = new System.Drawing.Point(3, 2);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(136, 167);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.vneck_tshirt;
            this.pictureBox3.Location = new System.Drawing.Point(357, 2);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(136, 167);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.alrism_tshirt;
            this.pictureBox2.Location = new System.Drawing.Point(181, 2);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(136, 167);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Takehome_08_Adelio_Surya_Putra_Pratama.Properties.Resources.tshirt_kerah_bulat;
            this.pictureBox1.Location = new System.Drawing.Point(3, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(136, 167);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(955, 570);
            this.Controls.Add(this.panel_other);
            this.Controls.Add(this.panel_acc);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.panel_shoes);
            this.Controls.Add(this.panel_shorts);
            this.Controls.Add(this.panel_pants);
            this.Controls.Add(this.panel_shirt);
            this.Controls.Add(this.panel_tshirt);
            this.Controls.Add(this.tb_t);
            this.Controls.Add(this.tb_st);
            this.Controls.Add(this.lbl_total);
            this.Controls.Add(this.lbl_subtotal);
            this.Controls.Add(this.dgv_harga);
            this.Controls.Add(this.menu);
            this.MainMenuStrip = this.menu;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_harga)).EndInit();
            this.panel_tshirt.ResumeLayout(false);
            this.panel_tshirt.PerformLayout();
            this.panel_shirt.ResumeLayout(false);
            this.panel_shirt.PerformLayout();
            this.panel_pants.ResumeLayout(false);
            this.panel_pants.PerformLayout();
            this.panel_shorts.ResumeLayout(false);
            this.panel_shorts.PerformLayout();
            this.panel_shoes.ResumeLayout(false);
            this.panel_shoes.PerformLayout();
            this.panel_acc.ResumeLayout(false);
            this.panel_acc.PerformLayout();
            this.panel_other.ResumeLayout(false);
            this.panel_other.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_upload)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menu;
        private System.Windows.Forms.ToolStripMenuItem ms_top;
        private System.Windows.Forms.ToolStripMenuItem ms_bot;
        private System.Windows.Forms.ToolStripMenuItem ms_acc;
        private System.Windows.Forms.ToolStripMenuItem ms_other;
        private System.Windows.Forms.DataGridView dgv_harga;
        private System.Windows.Forms.Label lbl_subtotal;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.TextBox tb_st;
        private System.Windows.Forms.TextBox tb_t;
        private System.Windows.Forms.ToolStripMenuItem ms_tshirt;
        private System.Windows.Forms.ToolStripMenuItem ms_shirt;
        private System.Windows.Forms.ToolStripMenuItem ms_pants;
        private System.Windows.Forms.ToolStripMenuItem ms_lpants;
        private System.Windows.Forms.ToolStripMenuItem ms_shoes;
        private System.Windows.Forms.ToolStripMenuItem ms_jewel;
        private System.Windows.Forms.Panel panel_tshirt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button add_t_vneck;
        private System.Windows.Forms.Button add_t_alrism;
        private System.Windows.Forms.Button add_t_kerahbulat;
        private System.Windows.Forms.Panel panel_shirt;
        private System.Windows.Forms.Button add_s_halfblue;
        private System.Windows.Forms.Button add_s_colourblock;
        private System.Windows.Forms.Button add_s_cotton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel panel_pants;
        private System.Windows.Forms.Button add_p_bisnis;
        private System.Windows.Forms.Button add_p_jog;
        private System.Windows.Forms.Button add_p_cargo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Panel panel_shorts;
        private System.Windows.Forms.Button add_sh_sports;
        private System.Windows.Forms.Button add_sh_casual;
        private System.Windows.Forms.Button add_sh_cargo;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Panel panel_shoes;
        private System.Windows.Forms.Button add_shoes_superstar;
        private System.Windows.Forms.Button add_shoes_nike;
        private System.Windows.Forms.Button add_shoes_adidas;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button add_a_sunglas;
        private System.Windows.Forms.Button add_a_rolex;
        private System.Windows.Forms.Button add_a_mask;
        private System.Windows.Forms.Panel panel_acc;
        private System.Windows.Forms.Panel panel_other;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox tb_other_name;
        private System.Windows.Forms.Button add_other;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.PictureBox pb_upload;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox tb_other_price;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Label label41;
    }
}

