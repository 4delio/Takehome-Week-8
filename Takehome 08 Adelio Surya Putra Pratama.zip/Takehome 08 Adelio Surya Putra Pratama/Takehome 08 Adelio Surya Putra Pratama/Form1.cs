﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Takehome_08_Adelio_Surya_Putra_Pratama
{
    public partial class Form1 : Form
    {
        DataTable harga = new DataTable();
        string nama = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void ms_tshirt_Click(object sender, EventArgs e)
        {
            panel_acc.Visible = false;
            panel_shorts.Visible = false;
            panel_shoes.Visible = false;
            panel_shirt.Visible = false;
            panel_tshirt.Visible = true;
            panel_pants.Visible = false;
            panel_other.Visible = false;
        }

        private void ms_shirt_Click(object sender, EventArgs e)
        {
            panel_acc.Visible = false;
            panel_shorts.Visible = false;
            panel_shoes.Visible = false;
            panel_tshirt.Visible = false;
            panel_shirt.Visible = true;
            panel_pants.Visible = false;
            panel_other.Visible = false;
        }

        private void ms_pants_Click(object sender, EventArgs e)
        {
            panel_acc.Visible = false;
            panel_shorts.Visible = true;
            panel_shoes.Visible = false;
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_other.Visible = false;
        }

        private void ms_lpants_Click(object sender, EventArgs e)
        {
            panel_acc.Visible = false;
            panel_shorts.Visible = false;
            panel_shoes.Visible = false;
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = true;
            panel_other.Visible = false;
        }

        private void ms_shoes_Click(object sender, EventArgs e)
        {
            panel_acc.Visible = false;
            panel_shorts.Visible = false;
            panel_shoes.Visible = true;
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_other.Visible = false;
        }

        private void ms_jewel_Click(object sender, EventArgs e)
        {
            panel_acc.Visible = true;
            panel_other.Visible = false;
            panel_shorts.Visible = false;
            panel_shoes.Visible = false;
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            harga.Columns.Add("Nama Barang");
            harga.Columns.Add("Quantity");
            harga.Columns.Add("Harga (Rp)");
            harga.Columns.Add("Total");
            dgv_harga.DataSource = harga;
        }

        private void ms_other_Click(object sender, EventArgs e)
        {
            panel_acc.Visible = false;
            panel_other.Visible = true;
            panel_shorts.Visible = false;
            panel_shoes.Visible = false;
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
        }
        private void tambah(string barang,int hargas)
        {
            bool ada = false;
            for (int i = 0; i < harga.Rows.Count; i++)
            {
                if (harga.Rows[i][0].ToString() == barang)
                {
                    int quant = Convert.ToInt32(harga.Rows[i][1].ToString());
                    int total = Convert.ToInt32(harga.Rows[i][2].ToString().Replace(".", ""));
                    quant++;
                    total = quant * total;
                    harga.Rows[i][1] = quant.ToString("N0");
                    harga.Rows[i][3] = total.ToString("N0");
                    ada = true;
                    break;
                }
            }
            if (ada == false)
            {
                harga.Rows.Add(barang, 1, hargas.ToString("N0"), hargas.ToString("N0"));
            }
            ubah();
        }

        private void add_t_kerahbulat_Click(object sender, EventArgs e)
        {
            tambah("T-Shirt Kerah Bulat", 120000);
        }

        private void add_t_alrism_Click(object sender, EventArgs e)
        {
            tambah("Alrism T-shirt",150000);
        }

        private void add_t_vneck_Click(object sender, EventArgs e)
        {
            tambah("T-shirt VNeck", 170000);
        }

        private void ubah()
        {
            double st = 0;
            if (harga.Rows.Count > 0&& dgv_harga.Rows.Count>0)
            {
                for (int i = 0; i < harga.Rows.Count; i++)
                {
                    st += Convert.ToDouble(harga.Rows[i][3].ToString().Replace(".", ""));
                }
                tb_st.Text = "Rp. " + st.ToString("N0");
                tb_t.Text = "Rp. " + (st + (st * 10 / 100)).ToString("N0");
            }
            else
            {
                tb_st.Text = "Rp. 0";
                tb_t.Text = "Rp. 0";
            }
        }

        private void add_s_cotton_Click(object sender, EventArgs e)
        {
            tambah("Cotton Shirt", 159000);
        }

        private void add_s_colourblock_Click(object sender, EventArgs e)
        {
            tambah("Colourblock Shirt", 175000);
        }

        private void add_s_halfblue_Click(object sender, EventArgs e)
        {
            tambah("Halfblue Shirt", 169000);
        }

        private void add_p_cargo_Click(object sender, EventArgs e)
        {
            tambah("Cargo Pants", 159000);
        }

        private void add_p_jog_Click(object sender, EventArgs e)
        {
            tambah("Jogging Pants", 115000);
        }

        private void add_p_bisnis_Click(object sender, EventArgs e)
        {
            tambah("Business Pants", 139000);
        }

        private void add_sh_cargo_Click(object sender, EventArgs e)
        {
            tambah("Cargo Shorts", 109000);
        }

        private void add_sh_casual_Click(object sender, EventArgs e)
        {
            tambah("Summer Casual Shorts", 110000);
        }

        private void add_sh_sports_Click(object sender, EventArgs e)
        {
            tambah("Sport Shorts", 119000);
        }

        private void add_shoes_superstar_Click(object sender, EventArgs e)
        {
            tambah("Superstar Sneakers", 239000);
        }

        private void add_shoes_nike_Click(object sender, EventArgs e)
        {
            tambah("Nike AirMax", 550000);
        }

        private void add_shoes_adidas_Click(object sender, EventArgs e)
        {
            tambah("Adidas Running Shoes", 379000);
        }

        private void add_a_sunglas_Click(object sender, EventArgs e)
        {
            tambah("Sunglasses", 100000);
        }

        private void add_a_rolex_Click(object sender, EventArgs e)
        {
            tambah("Rolex Watch", 500000);
        }


        private void btn_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.ShowDialog();
            string lokasi = openFileDialog.FileName;
            pb_upload.Image = new Bitmap(lokasi);
            tb_other_name.Enabled = true;
            tb_other_price.Enabled = true;
            add_other.Enabled = true;
        }

        private void add_other_Click(object sender, EventArgs e)
        {
            tambah(tb_other_name.Text,Convert.ToInt32(tb_other_price.Text));
            pb_upload.Image = null;
            tb_other_name.Enabled = false;
            tb_other_price.Enabled = false;
            add_other.Enabled = false;
        }

        private void tb_other_price_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (harga.Rows.Count == 0)
            {
                MessageBox.Show("List is still empty");
            }
            else
            {
                int index = dgv_harga.CurrentRow.Index;
                harga.Rows.RemoveAt(index);
            }
            ubah();
        }

        private void add_a_necklace_Click_1(object sender, EventArgs e)
        {
            tambah("Ring Necklace", 459000);
        }
    }
}
